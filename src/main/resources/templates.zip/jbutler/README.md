|Aliases|Entity|Enum|Service|IService|DAO|IDAO|Controller|Page|
|---|---|---|---|---|---|---|---|---|
|package                |✓|✓|✓|✓|✓|✓|✓| |
|class                  |✓|✓|✓| |✓| |✓| |
|interface              | | | |✓| |✓| | |
|attributes             |✓|✓|✓| |✓| |✓| |
|methods                |✓| |✓|✓|✓|✓|✓| |
|associations           |✓| |✓| | | |✓| |
|generalizations        |✓| |✓| |✓| |✓| |
|realizations           | | |✓| |✓| | | |
|resultDependency       | | | | | | | | |
|navigationAssociation  | | | | | | | |✓|
|page                   | | | | | | | |✓|
|forms                  | | | | | | | |✓|
